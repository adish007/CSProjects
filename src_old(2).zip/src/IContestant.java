
public interface IContestant {
	
}
